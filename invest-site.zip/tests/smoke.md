# Testes de fumaça
- [ ] Home carrega sem erros
- [ ] Header/Footer aparecem
- [ ] KPIs renderizam
- [ ] Gráfico de alocação renderiza
