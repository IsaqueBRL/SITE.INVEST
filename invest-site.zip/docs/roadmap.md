# Roadmap
- [ ] Integrar dados reais via planilha (Google Sheets) ou JSON externo
- [ ] Adicionar autenticação leve (apenas localStorage)
- [ ] PWA (instalável)
- [ ] Temas claro/escuro
