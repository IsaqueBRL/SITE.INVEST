# Contribuindo
1. Faça um fork do repositório
2. Crie uma branch: `git checkout -b feature/minha-feature`
3. Commit: `git commit -m "feat: descrição da feature"`
4. Pull Request para `main`
