// Gráfico de pizza simples sem libs externas
(function(){
  function drawPie(canvas, slices) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const total = slices.reduce((s,x)=>s+x.value,0) || 1;
    let start = 0;
    slices.forEach((s, i) => {
      const angle = (s.value/total) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(canvas.width/2, canvas.height/2);
      ctx.arc(canvas.width/2, canvas.height/2, Math.min(canvas.width, canvas.height)/2 - 10, start, start + angle);
      ctx.closePath();
      ctx.fillStyle = `hsl(${(i*65)%360} 70% 52%)`;
      ctx.fill();
      start += angle;
    });
  }
  window.renderAllocChart = async function() {
    const canvas = document.getElementById('allocChart');
    const data = await fetch('./data/sample/assets.json').then(r=>r.json()).catch(()=>[]);
    const slices = data.map(d => ({ label: d.class, value: d.percent }));
    drawPie(canvas, slices);
  };
  document.addEventListener('DOMContentLoaded', window.renderAllocChart);
})();
