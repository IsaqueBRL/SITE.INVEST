// Serviço simples de dados locais (poderia apontar para APIs públicas)
const API = {
  async portfolio() {
    return fetch('/data/sample/portfolio.json').then(r=>r.json());
  },
  async news() {
    return fetch('/data/sample/news.json').then(r=>r.json());
  },
  async assets() {
    return fetch('/data/sample/assets.json').then(r=>r.json());
  }
};
