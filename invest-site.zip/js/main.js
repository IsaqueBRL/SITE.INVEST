// Inicialização da home
document.addEventListener('DOMContentLoaded', async () => {
  // carrega header/footer
  window.loadShell('/components/header.html','/components/footer.html');

  // KPIs e cards
  const portfolio = await API.portfolio().catch(()=>[]);
  const total = portfolio.reduce((s,x)=> s + x.qty * x.avg_price, 0);
  const deposits30d = 1500.00;  // valor de exemplo
  const ytd = 8.7;              // % exemplo

  document.getElementById('kpi-total').textContent = `R$ ${total.toFixed(2)}`;
  document.getElementById('kpi-deposits').textContent = `R$ ${deposits30d.toFixed(2)}`;
  document.getElementById('kpi-ytd').textContent = `${ytd.toFixed(2)}%`;

  window.renderCards('#cards');
});
