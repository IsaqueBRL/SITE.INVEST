// Carrega header/footer e registra helpers
window.loadShell = async function(headerPath = '/components/header.html', footerPath = '/components/footer.html') {
  const header = await fetch(headerPath).then(r=>r.text()).catch(()=>'');
  const footer = await fetch(footerPath).then(r=>r.text()).catch(()=>'');
  const $h = document.getElementById('site-header');
  const $f = document.getElementById('site-footer');
  if ($h) $h.innerHTML = header;
  if ($f) $f.innerHTML = footer;
};

// Render cards genéricos
window.renderCards = async function(selector = '#cards') {
  const root = document.querySelector(selector);
  if (!root) return;
  const data = await fetch('/data/sample/portfolio.json').then(r=>r.json()).catch(()=>[]);
  data.forEach(item => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<div class="card-title">${item.ticker} · ${item.type}</div>
      <div class="card-body">
        <div>Qtde: <strong>${item.qty}</strong></div>
        <div>Preço Médio: <strong>R$ ${item.avg_price.toFixed(2)}</strong></div>
        <div>Valor: <strong>R$ ${(item.qty * item.avg_price).toFixed(2)}</strong></div>
      </div>`;
    root.appendChild(card);
  });
};
